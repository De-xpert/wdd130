
HOW TO USE THIS PORTFOLIO WEBSITE

1. Open the folder in VS Code.
2. Replace placeholder text with your own information.
3. Replace image URLs with your own work.
4. Upload videos to YouTube or Vimeo and embed them.
5. Deploy for free on:
   - Netlify
   - Cloudflare Pages

DEPLOYMENT:
- Drag the entire folder into Netlify.
- Your website goes live instantly.

FILES:
- index.html = website structure
- style.css = design/style
- script.js = animations
